export const prices = [
  {
    _id: 0,
    name: 'Any',
    array: [],
  },
  {
    _id: 1,
    name: '0 to 100',
    array: [2, 100],
  },
  {
    _id: 2,
    name: '100 to 500',
    array: [101, 500],
  },
  {
    _id: 3,
    name: '500 to 1000',
    array: [501, 1000],
  },
  {
    _id: 4,
    name: '1000 to 5000',
    array: [1001, 5000],
  },
  {
    _id: 5,
    name: 'More then 5000',
    array: [5001, 100000],
  },
]
